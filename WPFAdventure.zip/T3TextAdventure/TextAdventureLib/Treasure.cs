﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventureLib
{
    public class Treasure : Item
    {
        // Fields

        // Constructor
        public Treasure() : base()
        {

        }
        public Treasure(string name, string description) : base(name, description)
        {

        }


    }
}
