﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventureLib
{
    public class StandardMessages
    {
        public static string Menu()
        {
            return "Choose an option:" +
                    "\n1. Build player" +
                    "\n2. Move North" +
                    "\n3. Move South" +
                    "\n4. Attack" +
                    "\n5. Exit";
        }
        public static string MenuError()
        {
            return "Invalid input! Please select a number from the menu.";
        }
        
        public static string RoomMove()
        {
            return "You have moved to room: ";
        }
    }
}
