﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventureLib
{
    public class Potion : Item
    {

        // Constructor
        public Potion() : base()
        {

        }

        public Potion(string name, string description) : base(name, description)
        {

        }

    }
}
